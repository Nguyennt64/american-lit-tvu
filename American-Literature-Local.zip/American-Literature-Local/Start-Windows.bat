@echo off
setlocal
cd /d "%~dp0"
py -3 --version >nul 2>&1
if not errorlevel 1 (
    py -3 start.py
    goto done
)
python --version >nul 2>&1
if not errorlevel 1 (
    python start.py
    goto done
)
echo Python 3 is required. Install it from https://www.python.org/downloads/
echo On Windows, enable "Add Python to PATH", then start this file again.
:done
pause
