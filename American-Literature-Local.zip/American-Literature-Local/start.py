#!/usr/bin/env python3
"""Serve the included static lectures locally. Python standard library only."""
import argparse
import functools
import http.server
import json
import pathlib
import threading
import urllib.request
import webbrowser

ROOT = pathlib.Path(__file__).resolve().parent / 'app'
IDENTITY = 'american-literature-local-v1'

class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      '.js': 'text/javascript', '.css': 'text/css',
                      '.json': 'application/json', '.svg': 'image/svg+xml'}

    def do_GET(self):
        if self.path == '/__local_app__':
            data = json.dumps({'app': IDENTITY}).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        super().do_GET()

    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        if self.path.endswith(('sw.js', '.html')) or self.path.endswith('/'):
            self.send_header('Cache-Control', 'no-cache')
        super().end_headers()

    def list_directory(self, path):
        self.send_error(404, 'Directory listing is disabled')
        return None

    def log_message(self, format, *args):
        if len(args) > 1 and str(args[1]) not in ('200', '304'):
            super().log_message(format, *args)


def main():
    parser = argparse.ArgumentParser(description='Open American Literature locally')
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    if not (ROOT / 'index.html').is_file():
        raise SystemExit('Missing app/index.html. Extract the complete ZIP before starting.')
    if not 1024 <= args.port <= 65535:
        raise SystemExit('Choose a port between 1024 and 65535.')
    handler = functools.partial(Handler, directory=str(ROOT))
    url = f'http://127.0.0.1:{args.port}/'
    try:
        server = http.server.ThreadingHTTPServer(('127.0.0.1', args.port), handler)
    except OSError:
        # Reuse only our positively identified server. Never stop another program.
        try:
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with opener.open(url + '__local_app__', timeout=2) as response:
                existing = json.load(response)
            if existing.get('app') == IDENTITY:
                print('The lecture is already running: ' + url)
                if not args.no_browser:
                    webbrowser.open(url)
                return
        except (OSError, ValueError):
            pass
        raise SystemExit(f'Port {args.port} is occupied. Close the previous lecture window, '
                         f'or run: python start.py --port {args.port + 1}')
    print('\nAMERICAN LITERATURE - LOCAL\n')
    print('Open in your browser: ' + url)
    print('Only this computer can connect. No internet is needed for the core lectures.')
    print('Keep this terminal open. Press Ctrl+C here to stop.\n')
    if not args.no_browser:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nLecture server stopped.')
    finally:
        server.server_close()

if __name__ == '__main__':
    main()
