#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required. Install from https://www.python.org/downloads/"
  read -r -p "Press Enter to close." _reply
  exit 1
fi
python3 start.py
read -r -p "Press Enter to close." _reply
