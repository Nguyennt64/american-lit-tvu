# American Literature — chạy trên máy cá nhân

Ứng dụng chạy trong trình duyệt trên máy của bạn. Không cần Node.js, npm, tài khoản, hosting hay môi trường đám mây. Cần Python 3 và trình duyệt hiện đại (Chrome, Edge, Firefox hoặc Safari). Python chưa có thì cài một lần từ https://www.python.org/downloads/; Windows chọn “Add Python to PATH”. Sau đó nội dung bài giảng chạy không cần internet.

## Bắt đầu

1. Giải nén **toàn bộ** file ZIP vào một thư mục, không chạy ngay bên trong ZIP.
2. Windows: nhấp đúp **Start-Windows.bat**.
3. macOS: mở **Start-macOS.command**. Nếu hệ thống không cho chạy, dùng Terminal tại thư mục vừa giải nén và gõ `python3 start.py`.
4. Linux: chạy `sh Start-Linux.sh`, hoặc `python3 start.py`.
5. Trình duyệt tự mở trang chọn bài giảng. Nếu không tự mở, nhập `http://127.0.0.1:8765/` vào trình duyệt.

Giữ cửa sổ dòng lệnh mở khi sử dụng. Nhấn Ctrl+C trong cửa sổ đó để dừng; đóng tab trình duyệt không tự dừng chương trình. Máy chủ chỉ nhận kết nối từ máy của bạn (127.0.0.1), không mở cho các máy khác trong mạng.

Nếu cổng 8765 đang do chương trình khác sử dụng, chạy `python start.py --port 8766` trên Windows hoặc `python3 start.py --port 8766` trên macOS/Linux. Dữ liệu trình duyệt phụ thuộc địa chỉ/cổng: nên dùng cổng mặc định nhất quán để giữ tiến độ và chỉnh sửa.

## Sử dụng

- Chọn Meeting 1 hoặc Meeting 2; Fullscreen để trình chiếu.
- Có 79 trang giảng: Meeting 1 có 43 trang, Meeting 2 có 36 trang. Chương lịch sử Meeting 1 có 15 trang, gồm 12 trang phát triển sáu nhóm giai đoạn, với lời giảng chi tiết EN/VI.
- Nút ghi chú mở cửa sổ giảng viên riêng: giữ trên laptop, chiếu cửa sổ bài giảng. Ghi chú fallback sẽ hiển thị trên màn hình hiện tại.
- Settings → Enable teacher mode & edit content để sửa bài giảng, import/export JSON.
- Nội dung chỉnh sửa, tiến độ và thao tác giảng viên lưu trong trình duyệt của máy đó. Export lecture JSON và Export class recap để sao lưu. Không có đồng bộ đám mây.
- Link nguồn bên ngoài chỉ dùng được khi có internet; nội dung cốt lõi và hoạt động đều có sẵn trong gói.
- Không mở trực tiếp app/index.html bằng cách nhấp đúp; hãy dùng file Start để tài nguyên và cửa sổ ghi chú hoạt động đúng.

## Phạm vi kiểm tra

Máy chủ Python và bài giảng được chạy/kiểm tra thực tế trên Linux trong môi trường xây dựng; script Windows/macOS được cung cấp nhưng chưa kiểm tra trên máy Windows/macOS thật. Bản ứng dụng đã đạt kiểm thử chức năng và hình ảnh; chi tiết nằm trong gói mã nguồn đã bàn giao.

Nguồn Meeting 1 gốc chưa tải được vì giới hạn kích thước; nguồn thơ/website bên ngoài còn phần xác minh chưa hoàn tất. Các giới hạn nội dung này vẫn áp dụng cho bản local. Không có video/âm thanh lưu trữ được đóng gói dưới giả định đã có quyền sử dụng.

## Bản trình giảng mới

Mặc định là Lecture: mũi tên phải / Next scene chuyển trang trực tiếp; nhấn luận điểm để làm nổi bật; Space mở kết luận. Ghi chú chi tiết giữ trong cửa sổ riêng. Settings → Teaching mode bật hoạt động tùy chọn nếu cần. Nền sáng, font Source Serif 4 / Source Sans 3 có sẵn offline.

Dữ liệu bản cũ được giữ trong các khóa v1, nhưng không tự ghi đè nội dung bản v2. Nếu đã chỉnh sửa bản cũ, xuất JSON từ bản cũ trước khi thay thư mục. Dừng cửa sổ máy chủ cũ rồi giải nén và chạy bản mới.

Logo TVU mới chưa được chèn: bài đăng Facebook do người dùng cung cấp và website chính thức bị môi trường xây dựng chặn, nên chưa lấy được ảnh xác minh. Icon sách không phải logo trường. Xem REVIEW_LECTURE_EDITION_VI.md để biết các sửa đổi và giới hạn.
