# Review và hiệu chỉnh bản trình giảng — 09/10/2026

Bản trước dành quá nhiều thao tác cho hoạt động lớp; tổng quan lịch sử chưa đủ để giảng; giao diện tối và font hệ thống làm giảm tính nhất quán. Bản này chuyển trọng tâm sang nội dung được trình bày trực tiếp và các thao tác điều khiển của giảng viên.

- Meeting 1: 43 trang, trong đó chương lịch sử có 15 trang: tổng quan, 12 trang phát triển sáu nhóm giai đoạn, so sánh và tổng hợp. Mỗi giai đoạn có bối cảnh, đặc điểm hình thức, tiếng nói tiêu biểu, lời giảng EN/VI và liên hệ văn bản. Ranh giới thời gian là gần đúng; văn học bản địa tiếp tục tồn tại, không phải một giai đoạn đã kết thúc. Naturalism là xu hướng liên hệ Realism, không phải nhãn thay thế mọi tác phẩm cùng thời.
- Meeting 2: 36 trang; chuyển câu hỏi/đáp án cũ thành các luận điểm giảng giải hiển thị trực tiếp. Các hoạt động cũ còn trong chế độ tùy chọn, không cản trở tiến trình giảng.
- Mặc định nền trắng–xanh nhạt, chữ xanh navy; Source Serif 4 cho tiêu đề, Source Sans 3 cho nội dung. Font Latin và tiếng Việt cùng giấy phép OFL được đóng gói offline. Bố cục 16:9 có vùng an toàn, phân cấp tiêu đề, dòng đọc và khoảng trắng rõ ràng.
- Nhấn luận điểm để nhấn mạnh; Space mở kết luận; mũi tên phải chuyển trang; ghi chú và lời giảng chi tiết mở riêng. Kết thúc truyện vẫn cần thao tác mở rõ ràng để giữ trình tự kể.
- Bộ nhớ nội dung/tiến độ dùng khóa v2 để dữ liệu cũ không che khuất bản mới. Các khóa v1 vẫn được giữ nguyên; nếu đã chỉnh sửa bản cũ, hãy xuất JSON từ bản cũ trước khi chuyển sang bản mới. Không tự nhập hoặc ghi đè chỉnh sửa cũ.

## Giới hạn cần xử lý

Không tự chứng nhận “10/10”. Đánh giá cuối cùng cần giảng thử thực tế và đối chiếu tài liệu môn học. PPTX Meeting 1 chưa tải được; các trang lịch sử mới là phần biên soạn bổ sung, không khẳng định sao chép slide gốc. Các trang mới không gắn số slide nguồn giả định. Nguồn thơ còn những điểm cần đối chiếu như ghi trong SOURCE_AUDIT.md.

Logo: người dùng cung cấp bài đăng Facebook TVU CET, post 1430421322431769. Cả Facebook lẫn website chính thức bị proxy chặn HTTP 403; chưa lấy được ảnh để xác minh logo hiện hành. Biểu tượng sách là icon chức năng, không phải logo trường. Cần tệp logo PNG/SVG hoặc URL ảnh truy cập được để hoàn tất yêu cầu nhận diện; không dựng lại một logo phỏng đoán.
