#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 is required. Install Python 3 with your distribution's package manager."
  exit 1
fi
exec python3 start.py
