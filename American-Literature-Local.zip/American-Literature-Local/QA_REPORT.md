
## Lecture edition validation — 2026-10-09

- Production build, TypeScript and ESLint pass. A Vite bundle-size advisory remains; it is not a build failure.
- 12 retained functional tests pass in the regression run. The largest-excerpt/glossary test initially failed after font replacement; quote/title spacing was corrected and this test passed on rerun. Together the 13 retained functional cases are verified.
- Three new cases pass: historical schema/script coverage, lecturer focus/navigation/private bilingual scripts, offline font and route availability.
- Both full-scene visual cases pass on the final presentation styling: 43 + 36 scenes × six viewports × two states = 948 geometry checks; zero overflow audit entries. 79 reference screenshots at 1920×1080; additional viewports checked geometrically. Selected home/history/poetry/presenter screenshots inspected visually. These checks verify geometry and functions, not a subjective “10/10” score.
- Portable stdlib Python server on 127.0.0.1:8875 passes real-browser lecture/navigation/font/offline reload checks. Native Windows/macOS launch scripts remain untested here.
- Root and /literature/ builds pass; subpath route and offline font paths verified from generated output. Official logo image is still unavailable, documented in REVIEW_LECTURE_EDITION_VI.md.
